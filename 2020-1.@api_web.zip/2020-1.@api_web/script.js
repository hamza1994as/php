window.onload = ()=>{
   
   document.querySelector(".sick-container").style.display='flex';
   document.querySelector('.loading').style.display='none';
   
}

function playBells(permisssion){
   
   let bells = document.getElementById("bells"),
   popup = document.querySelector(".popup"),
   text = document.getElementById('text');
   
   if(permisssion){
      popup.style.display = 'none';
      bells.play();
   }else{
      text.textContent = "Whether you give permission or not i'll play czz i'm evil";
      document.querySelector('.Deny').style.display='none';
      document.querySelector('.Allow').textContent = 'Damn_You';
   }
   
}